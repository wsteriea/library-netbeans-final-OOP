/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package silverio_finals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

/**
 *
 * @author MICAELLA
 */
public class Silverio_Finals {
    
    
    
    public static ArrayList<String> name = new ArrayList<String>(Arrays.asList(
            "Mica", "Rengoku","Bene"));
    
    public static ArrayList<String> username = new ArrayList<String>(Arrays.asList(
            "mica", "rengoku","bene"));
    public static ArrayList<String> password = new ArrayList<String>(Arrays.asList(
            "cutie", "flame","bene"));
    
    
    //books
    public static ArrayList<String> title = new ArrayList<String>(Arrays.asList(
            "Rich Dad Poor Dad", "The Notebook", "A Walk to Remember","The Lord of the Rings","To Kill a Mockingbird"));
    public static ArrayList<String> genre = new ArrayList<String>(Arrays.asList(
            "Finance", "Romance", "Romance","Novel","Novel"));
    public static ArrayList<String> author = new ArrayList<String>(Arrays.asList(
            "Robert T. Kiyosaki", "Nicholas Sparks", "Nicholas Sparks","J.R. R. Tolkien","Harper Lee"));
    public static ArrayList<String> year = new ArrayList<String>(Arrays.asList(
            "2000", "1996","1999","1954","1960"));
    
    //issuebook
    public static ArrayList<String> issueID = new ArrayList<String>();
    public static ArrayList<String> bkIssueNo = new ArrayList<String>();
    public static ArrayList<String> issuerNo = new ArrayList<String>();
    public static ArrayList<String> issuerName = new ArrayList<String>();  
    public static ArrayList<String> issuedB = new ArrayList<String>();
    public static ArrayList<Date> date = new ArrayList<Date>();
    public static ArrayList<Date> due = new ArrayList<Date>();
    //public static ArrayList<String> status = new ArrayList<String>();
    
    
    public static int attempts = 1;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
